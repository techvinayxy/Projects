// Select filter buttons and product cards
const filterButtons = document.querySelectorAll('.filter-btn');
const productCards = document.querySelectorAll('.product-card');
const cartButton = document.querySelector('.nav-links a[href="Cart.html"]');

// Initialize cart data and item count
let cart = new Set(); // Use a Set to track unique products
let cartCount = 0;

// Function to filter products based on selected category
function filterProducts(category) {
    productCards.forEach(card => {
        if (category === 'all' || card.getAttribute('data-category') === category) {
            card.style.display = 'block'; // Show matching products
        } else {
            card.style.display = 'none'; // Hide non-matching products
        }
    });
}

// Add event listeners to filter buttons
filterButtons.forEach(button => {
    button.addEventListener('click', (event) => {
        const category = event.target.getAttribute('data-category');
        filterProducts(category);
    });
});

// Add to cart functionality
productCards.forEach(card => {
    const addToCartButton = card.querySelector('.btn');
    const productName = card.querySelector('h3').textContent;

    addToCartButton.addEventListener('click', () => {
        if (cart.has(productName)) {
            // If the item is already in the cart, show a temporary error message
            if (!card.querySelector('.error-message')) {
                const errorMessage = document.createElement('p');
                errorMessage.textContent = 'This item is already in the cart.';
                errorMessage.className = 'error-message';
                errorMessage.style.color = 'red';
                errorMessage.style.fontSize = '0.9rem';
                errorMessage.style.marginTop = '10px';
                card.appendChild(errorMessage);

                // Remove the error message after 3 seconds
                setTimeout(() => {
                    errorMessage.remove();
                }, 3000);
            }
        } else {
            // Add item to cart
            cart.add(productName);
            cartCount++;

            // Update cart count in the cart button
            cartButton.textContent = `Cart (${cartCount})`;

            // Provide user feedback by temporarily changing the button text
            const originalText = addToCartButton.textContent;
            addToCartButton.textContent = 'Added!';
            setTimeout(() => {
                addToCartButton.textContent = originalText;
            }, 2000);
        }
    });
});

// Show all products on page load
filterProducts('all');
