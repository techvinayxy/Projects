// calculation.js
export function calculateArea(radius) {
    return Math.PI * radius * radius;
  }
  